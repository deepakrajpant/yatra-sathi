import { db } from "../firebase/config";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
export async function addReview(data:Record<string,unknown>){
  return addDoc(collection(db,"reviews"),{...data,createdAt:serverTimestamp()});
}
