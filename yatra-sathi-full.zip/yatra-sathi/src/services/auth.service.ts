import { auth, db } from "../firebase/config";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile } from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
export async function login(email:string,password:string){ return signInWithEmailAndPassword(auth,email,password); }
export async function register(name:string,email:string,password:string){
  const cred=await createUserWithEmailAndPassword(auth,email,password);
  await updateProfile(cred.user,{displayName:name});
  await setDoc(doc(db,"users",cred.user.uid),{name,email,role:"passenger",createdAt:serverTimestamp()},{merge:true});
  return cred;
}
export async function logout(){ return signOut(auth); }
