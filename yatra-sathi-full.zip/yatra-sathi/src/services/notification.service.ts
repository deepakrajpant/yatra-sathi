export function notify(title:string,message:string){
  if("Notification" in window && Notification.permission==="granted") new Notification(title,{body:message});
}
export async function requestNotificationPermission(){
  if(!("Notification" in window)) return "unsupported";
  return Notification.requestPermission();
}
