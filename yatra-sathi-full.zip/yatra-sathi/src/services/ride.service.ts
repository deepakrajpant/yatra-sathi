import { db } from "../firebase/config";
import { collection, getDocs, addDoc, serverTimestamp } from "firebase/firestore";
import type { Ride } from "../types/ride";
export async function getRides():Promise<Ride[]>{
  const snap=await getDocs(collection(db,"rides"));
  return snap.docs.map(d=>({id:d.id,...d.data()} as Ride));
}
export async function createRide(data:Omit<Ride,"id"|"driver">){
  return addDoc(collection(db,"rides"),{...data,createdAt:serverTimestamp()});
}
