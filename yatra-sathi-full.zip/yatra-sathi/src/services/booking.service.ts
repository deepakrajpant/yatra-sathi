import { db } from "../firebase/config";
import { collection, addDoc, updateDoc, doc, serverTimestamp } from "firebase/firestore";
import type { Booking } from "../types/booking";
export async function createBooking(data:Omit<Booking,"id"|"createdAt">){
  return addDoc(collection(db,"bookings"),{...data,createdAt:serverTimestamp()});
}
export async function updateBooking(id:string,status:Booking["status"]){
  return updateDoc(doc(db,"bookings",id),{status,updatedAt:serverTimestamp()});
}
