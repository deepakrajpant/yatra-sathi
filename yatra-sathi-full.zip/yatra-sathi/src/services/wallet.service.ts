import type { Wallet } from "../types/wallet";
export const emptyWallet: Wallet = { balance: 0, transactions: [] };
