export async function createEsewaPayment(payload:{bookingId:string,amount:number}){
  const base=import.meta.env.VITE_API_BASE_URL;
  if(!base) throw new Error("Payment backend is not configured.");
  const res=await fetch(`${base}/payments/esewa/initiate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  if(!res.ok) throw new Error("Could not initiate eSewa payment.");
  return res.json();
}
