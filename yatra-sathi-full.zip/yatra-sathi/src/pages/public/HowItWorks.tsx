import Card from "../../components/ui/Card";
export default function HowItWorks(){return <div className="mx-auto max-w-4xl px-4 py-12"><h1 className="text-4xl font-black">How YatraSathi works</h1><Card className="mt-7"><p className="leading-8 text-slate-600">Search a route, compare rides, send a booking request, confirm the trip, travel safely, and leave a review.</p></Card></div>}
