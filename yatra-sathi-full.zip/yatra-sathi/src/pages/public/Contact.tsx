import Card from "../../components/ui/Card";
export default function Contact(){return <div className="mx-auto max-w-4xl px-4 py-12"><h1 className="text-4xl font-black">Contact</h1><Card className="mt-7"><p className="leading-8 text-slate-600">For support, use the support email configured in the brand settings. In production, connect this page to a secure contact backend.</p></Card></div>}
