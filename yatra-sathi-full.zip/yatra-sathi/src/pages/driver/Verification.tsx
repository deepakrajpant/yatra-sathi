import Card from "../../components/ui/Card";
export default function Verification(){return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-3xl font-black">Driver verification</h1><Card className="mt-6"><p className="text-slate-500">This module is ready for Firebase data binding. Demo UI is available from the driver dashboard.</p></Card></div>}
