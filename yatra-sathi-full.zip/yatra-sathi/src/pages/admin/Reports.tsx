import Card from "../../components/ui/Card";
export default function Reports(){return <div className="mx-auto max-w-6xl px-4 py-10"><h1 className="text-3xl font-black">Admin · Reports</h1><Card className="mt-6"><p className="text-slate-500">Admin data table and actions can be connected to Firestore collection <code className="rounded bg-slate-100 px-1">reports</code>.</p></Card></div>}
