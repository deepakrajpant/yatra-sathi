import Card from "../../components/ui/Card";
export default function Reviews(){return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-3xl font-black">Reviews</h1><Card className="mt-6"><p className="text-slate-500">Your reviews and ratings will appear here.</p></Card></div>}
