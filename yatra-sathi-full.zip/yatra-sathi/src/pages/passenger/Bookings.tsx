import Card from "../../components/ui/Card";
export default function Bookings(){return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-3xl font-black">My bookings</h1><Card className="mt-6"><p className="text-slate-500">Your pending, confirmed, ongoing and completed bookings will appear here.</p></Card></div>}
