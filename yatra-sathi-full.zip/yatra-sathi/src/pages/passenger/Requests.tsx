import Card from "../../components/ui/Card";
export default function Requests(){return <div className="mx-auto max-w-5xl px-4 py-10"><h1 className="text-3xl font-black">Ride requests</h1><Card className="mt-6"><p className="text-slate-500">Booking requests sent by you will appear here.</p></Card></div>}
