export { storage } from "./config";
export { ref, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage";
