import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { auth } from "../firebase/config";
import type { UserProfile } from "../types/user";

interface AuthValue { user:User|null; profile:UserProfile|null; loading:boolean; demoLogin:(role:"passenger"|"driver"|"admin")=>void; demoLogout:()=>void; }
const C=createContext<AuthValue|null>(null);
export function AuthProvider({children}:{children:ReactNode}){
  const [user,setUser]=useState<User|null>(null); const [profile,setProfile]=useState<UserProfile|null>(null); const [loading,setLoading]=useState(true);
  useEffect(()=>onAuthStateChanged(auth,u=>{setUser(u);setLoading(false);}),[]);
  useEffect(()=>{const raw=localStorage.getItem("ys-demo-user"); if(raw) setProfile(JSON.parse(raw));},[]);
  const demoLogin=(role:"passenger"|"driver"|"admin")=>{const p:UserProfile={id:`demo-${role}`,name:role==="admin"?"YatraSathi Admin":role==="driver"?"Demo Driver":"Demo Passenger",email:`${role}@demo.local`,role,verified:true,createdAt:new Date().toISOString()}; setProfile(p); localStorage.setItem("ys-demo-user",JSON.stringify(p));};
  const demoLogout=()=>{setProfile(null);localStorage.removeItem("ys-demo-user");};
  return <C.Provider value={{user,profile,loading,demoLogin,demoLogout}}>{children}</C.Provider>;
}
export const useAuth=()=>{const c=useContext(C); if(!c) throw new Error("useAuth must be used inside AuthProvider"); return c;};
