import {createContext,useContext,useState,type ReactNode} from "react";
type Notice={id:string,type:"success"|"error"|"warning"|"info",message:string};
const C=createContext<{notices:Notice[];push:(message:string,type?:Notice["type"])=>void;remove:(id:string)=>void}>({notices:[],push:()=>{},remove:()=>{}});
export function NotificationProvider({children}:{children:ReactNode}){
 const [notices,setNotices]=useState<Notice[]>([]);
 const push=(message:string,type:Notice["type"]="info")=>{const id=crypto.randomUUID();setNotices(n=>[...n,{id,message,type}]);setTimeout(()=>setNotices(n=>n.filter(x=>x.id!==id)),3500)};
 const remove=(id:string)=>setNotices(n=>n.filter(x=>x.id!==id));
 return <C.Provider value={{notices,push,remove}}>{children}</C.Provider>
}
export const useNotifications=()=>useContext(C);
