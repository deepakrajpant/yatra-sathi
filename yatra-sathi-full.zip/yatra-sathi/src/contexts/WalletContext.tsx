import { createContext,useContext,useEffect,useState,type ReactNode } from "react";
import type { Transaction,Wallet } from "../types/wallet";
const C=createContext<{wallet:Wallet;addTransaction:(t:Omit<Transaction,"id"|"createdAt">)=>void}>({wallet:{balance:0,transactions:[]},addTransaction:()=>{}});
export function WalletProvider({children}:{children:ReactNode}){
 const [wallet,setWallet]=useState<Wallet>(()=>JSON.parse(localStorage.getItem("ys-wallet")||'{"balance":2500,"transactions":[]}'));
 useEffect(()=>localStorage.setItem("ys-wallet",JSON.stringify(wallet)),[wallet]);
 const addTransaction=(t:Omit<Transaction,"id"|"createdAt">)=>setWallet(w=>{const tx={...t,id:crypto.randomUUID(),createdAt:new Date().toISOString()};return {...w,balance:w.balance+(t.type==="credit"?t.amount:-t.amount),transactions:[tx,...w.transactions]};});
 return <C.Provider value={{wallet,addTransaction}}>{children}</C.Provider>
}
export const useWallet=()=>useContext(C);
