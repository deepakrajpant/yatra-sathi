export const required = (value: string, label = "This field") =>
  value.trim() ? "" : `${label} is required.`;
export const validEmail = (value: string) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? "" : "Enter a valid email.";
export const positiveNumber = (value: number, label = "Value") =>
  Number.isFinite(value) && value > 0 ? "" : `${label} must be greater than 0.`;
