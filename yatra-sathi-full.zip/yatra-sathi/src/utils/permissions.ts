import type { UserRole } from "../types/user";
export const canAccess = (role: UserRole | undefined, allowed: UserRole[]) =>
  !!role && allowed.includes(role);
