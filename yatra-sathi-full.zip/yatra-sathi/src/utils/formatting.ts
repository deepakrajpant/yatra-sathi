export const formatNPR = (amount: number) =>
  new Intl.NumberFormat("en-NP", { style: "currency", currency: "NPR", maximumFractionDigits: 0 }).format(amount);
export const formatDate = (date: string) =>
  new Intl.DateTimeFormat("en-NP", { dateStyle: "medium" }).format(new Date(date));
export const formatTime = (time: string) => {
  const [h,m] = time.split(":").map(Number);
  const d = new Date(); d.setHours(h,m,0,0);
  return new Intl.DateTimeFormat("en-NP",{hour:"numeric",minute:"2-digit"}).format(d);
};
