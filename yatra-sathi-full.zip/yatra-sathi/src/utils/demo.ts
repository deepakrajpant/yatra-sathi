import type {Ride} from "../types/ride";
export const demoRides:Ride[]=[
{id:"demo-1",driverId:"d1",driver:{id:"d1",name:"Suman Thapa",rating:4.9,totalRides:128,verified:true},from:"Butwal",to:"Kathmandu",date:"2026-09-20",time:"07:00",seats:4,availableSeats:2,price:950,vehicle:"car",status:"scheduled",notes:"Comfortable morning ride. 1 small bag per passenger."},
{id:"demo-2",driverId:"d2",driver:{id:"d2",name:"Ramesh Karki",rating:4.7,totalRides:82,verified:true},from:"Bhairahawa",to:"Pokhara",date:"2026-09-21",time:"06:30",seats:3,availableSeats:1,price:800,vehicle:"car",status:"scheduled"},
{id:"demo-3",driverId:"d3",driver:{id:"d3",name:"Aashish Bohara",rating:4.8,totalRides:64,verified:true},from:"Dhangadhi",to:"Nepalgunj",date:"2026-09-22",time:"08:00",seats:2,availableSeats:1,price:650,vehicle:"bike",status:"scheduled"}
];
