import {CheckCircle2,AlertCircle,Info,TriangleAlert,X} from "lucide-react";
export default function Toast({type="info",message,onClose}:{type?:"success"|"error"|"warning"|"info";message:string;onClose?:()=>void}){
 const I={success:CheckCircle2,error:AlertCircle,warning:TriangleAlert,info:Info}[type]; return <div className="flex items-center gap-3 rounded-xl border bg-white p-4 shadow-lg"><I size={19}/><span className="flex-1 text-sm">{message}</span>{onClose&&<button onClick={onClose}><X size={16}/></button>}</div>
}
