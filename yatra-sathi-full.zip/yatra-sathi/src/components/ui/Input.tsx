import type {InputHTMLAttributes} from "react";
export default function Input({label,error,helperText,className="",...p}:InputHTMLAttributes<HTMLInputElement>&{label?:string;error?:string;helperText?:string}){
 return <label className="block space-y-1.5"><span className="text-sm font-semibold text-slate-700">{label}</span><input className={`w-full rounded-xl border px-3.5 py-3 outline-none transition focus:border-[#4361ee] focus:ring-2 focus:ring-blue-100 ${error?"border-red-400":"border-slate-200"} ${className}`} {...p}/>{error&&<span className="text-xs text-red-600">{error}</span>}{helperText&&!error&&<span className="text-xs text-slate-500">{helperText}</span>}</label>
}
