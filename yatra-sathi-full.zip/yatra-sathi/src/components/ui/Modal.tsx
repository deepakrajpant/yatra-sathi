import {useEffect,type ReactNode} from "react";
import {X} from "lucide-react";
export default function Modal({open,onClose,title,children,size="md"}:{open:boolean;onClose:()=>void;title:string;children:ReactNode;size?:"sm"|"md"|"lg"}){
 useEffect(()=>{const f=(e:KeyboardEvent)=>e.key==="Escape"&&onClose();window.addEventListener("keydown",f);return()=>window.removeEventListener("keydown",f)},[onClose]);
 if(!open)return null; const w={sm:"max-w-md",md:"max-w-xl",lg:"max-w-3xl"}[size];
 return <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4" onMouseDown={onClose}><div className={`w-full ${w} rounded-2xl bg-white shadow-2xl`} onMouseDown={e=>e.stopPropagation()}><div className="flex items-center justify-between border-b p-5"><h3 className="font-bold text-lg">{title}</h3><button onClick={onClose} className="rounded-lg p-2 hover:bg-slate-100"><X size={20}/></button></div><div className="p-5">{children}</div></div></div>
}
