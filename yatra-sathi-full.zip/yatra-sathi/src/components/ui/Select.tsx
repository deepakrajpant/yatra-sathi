import type {SelectHTMLAttributes} from "react";
export interface SelectOption{label:string;value:string}
export default function Select({label,options,error,...p}:SelectHTMLAttributes<HTMLSelectElement>&{label?:string;options:SelectOption[];error?:string}){
 return <label className="block space-y-1.5"><span className="text-sm font-semibold text-slate-700">{label}</span><select className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 outline-none focus:border-[#4361ee]" {...p}>{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select>{error&&<span className="text-xs text-red-600">{error}</span>}</label>
}
