import type React from 'react';
export default function Badge({children,tone="default"}:{children:React.ReactNode;tone?:"default"|"success"|"warning"|"danger"|"info"}){
 const c={default:"bg-slate-100 text-slate-700",success:"bg-emerald-100 text-emerald-700",warning:"bg-amber-100 text-amber-700",danger:"bg-red-100 text-red-700",info:"bg-blue-100 text-blue-700"}[tone];
 return <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${c}`}>{children}</span>
}
