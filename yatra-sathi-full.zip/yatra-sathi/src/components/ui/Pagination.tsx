import Button from "./Button";
export default function Pagination({page,total,onChange}:{page:number;total:number;onChange:(p:number)=>void}){
 return <div className="flex items-center justify-between"><span className="text-sm text-slate-500">Page {page} of {total}</span><div className="flex gap-2"><Button variant="outline" size="sm" disabled={page<=1} onClick={()=>onChange(page-1)}>Previous</Button><Button variant="outline" size="sm" disabled={page>=total} onClick={()=>onChange(page+1)}>Next</Button></div></div>
}
