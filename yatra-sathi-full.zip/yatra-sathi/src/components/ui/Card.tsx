import type React from 'react';
export default function Card({children,padding="md",className=""}:{children:React.ReactNode;padding?:"none"|"sm"|"md"|"lg";className?:string}){
 const p={none:"",sm:"p-3",md:"p-5",lg:"p-7"}[padding]; return <div className={`rounded-2xl border border-slate-200 bg-white shadow-sm ${p} ${className}`}>{children}</div>
}
