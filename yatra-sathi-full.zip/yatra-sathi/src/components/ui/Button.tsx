import type {ButtonHTMLAttributes} from "react";
interface Props extends ButtonHTMLAttributes<HTMLButtonElement>{variant?:"primary"|"secondary"|"outline"|"danger"|"ghost";size?:"sm"|"md"|"lg";loading?:boolean}
export default function Button({variant="primary",size="md",loading=false,className="",children,...p}:Props){
 const v={primary:"bg-[#4361ee] text-white hover:bg-[#3651d4]",secondary:"bg-slate-900 text-white hover:bg-slate-800",outline:"border border-slate-300 bg-white text-slate-800 hover:bg-slate-50",danger:"bg-red-600 text-white hover:bg-red-700",ghost:"text-slate-700 hover:bg-slate-100"}[variant];
 const s={sm:"px-3 py-2 text-sm",md:"px-4 py-2.5 text-sm",lg:"px-5 py-3 text-base"}[size];
 return <button disabled={loading||p.disabled} className={`rounded-xl font-semibold transition disabled:cursor-not-allowed disabled:opacity-50 ${v} ${s} ${className}`} {...p}>{loading?"Please wait…":children}</button>
}
