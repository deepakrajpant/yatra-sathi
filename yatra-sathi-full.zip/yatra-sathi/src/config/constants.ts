export const NEPAL_CITIES = [
  "Kathmandu","Pokhara","Butwal","Bhairahawa","Dhangadhi","Nepalgunj",
  "Chitwan","Biratnagar","Dharan","Hetauda","Birgunj","Janakpur","Birtamode"
];
export const RIDE_STATUSES = ["scheduled","active","completed","cancelled"] as const;
export const BOOKING_STATUSES = ["pending","confirmed","ongoing","completed","cancelled","rejected"] as const;
