export const brand = {
  name: "YatraSathi",
  tagline: "साथी बनौं, सुरक्षित यात्रा गरौं",
  description: "Nepal-focused smart ride sharing for passengers and drivers.",
  primary: "#4361ee",
  support: "support@yatrasathi.com",
  currency: "NPR",
};
