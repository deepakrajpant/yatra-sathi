import { useEffect,useState } from "react";
import type { Ride } from "../types/ride";
import { getRides } from "../services/ride.service";
export function useRides(){const [rides,setRides]=useState<Ride[]>([]);const [loading,setLoading]=useState(false);useEffect(()=>{let on=true;setLoading(true);getRides().then(x=>on&&setRides(x)).catch(()=>{}).finally(()=>on&&setLoading(false));return()=>{on=false}},[]);return{rides,loading,setRides};}
