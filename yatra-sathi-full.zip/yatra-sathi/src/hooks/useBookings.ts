import {useState} from "react";
import type {Booking} from "../types/booking";
export function useBookings(){const [bookings,setBookings]=useState<Booking[]>([]);return{bookings,setBookings};}
