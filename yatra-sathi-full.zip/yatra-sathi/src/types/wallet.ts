export type TransactionType = "credit" | "debit";
export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  title: string;
  status: "success" | "pending" | "failed";
  createdAt: string;
  reference?: string;
}
export interface Wallet {
  balance: number;
  transactions: Transaction[];
}
