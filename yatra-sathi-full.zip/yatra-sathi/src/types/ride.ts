import type { Driver } from "./driver";
export type RideStatus = "scheduled" | "active" | "completed" | "cancelled";
export interface Ride {
  id: string;
  driverId: string;
  driver: Driver;
  from: string;
  to: string;
  date: string;
  time: string;
  seats: number;
  availableSeats: number;
  price: number;
  vehicle: string;
  status: RideStatus;
  notes?: string;
}
