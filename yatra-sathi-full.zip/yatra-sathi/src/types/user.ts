export type UserRole = "passenger" | "driver" | "admin";
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  photoURL?: string;
  verified?: boolean;
  createdAt: string;
}
