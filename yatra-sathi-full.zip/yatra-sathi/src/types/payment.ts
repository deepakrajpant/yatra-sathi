export type PaymentStatus = "pending" | "paid" | "failed" | "refunded";
export interface Payment {
  id: string;
  bookingId: string;
  amount: number;
  method: "esewa" | "wallet" | "cash";
  status: PaymentStatus;
  transactionId?: string;
  createdAt: string;
}
