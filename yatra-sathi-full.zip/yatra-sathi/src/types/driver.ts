export interface Driver {
  id: string;
  name: string;
  rating: number;
  totalRides: number;
  verified: boolean;
  phone?: string;
  photoURL?: string;
}
