export type BookingStatus = "pending" | "confirmed" | "ongoing" | "completed" | "cancelled" | "rejected";
export interface Booking {
  id: string;
  rideId: string;
  passengerId: string;
  seats: number;
  amount: number;
  status: BookingStatus;
  createdAt: string;
}
