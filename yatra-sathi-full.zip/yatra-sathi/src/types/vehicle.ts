export type VehicleType = "car" | "bike" | "van" | "bus";
export interface Vehicle {
  id: string;
  driverId: string;
  type: VehicleType;
  brand: string;
  model: string;
  numberPlate: string;
  color?: string;
  seats: number;
  verified: boolean;
}
