import {onCall} from "firebase-functions/v2/https";
import {onDocumentCreated} from "firebase-functions/v2/firestore";
import {initializeApp} from "firebase-admin/app";
import {getFirestore} from "firebase-admin/firestore";
initializeApp();
const db=getFirestore();

export const createBooking=onCall(async request=>{
  if(!request.auth) throw new Error("Authentication required.");
  const {rideId,seats}=request.data as {rideId:string;seats:number};
  if(!rideId||!Number.isInteger(seats)||seats<1) throw new Error("Invalid booking.");
  const ref=await db.collection("bookings").add({
    rideId,passengerId:request.auth.uid,seats,status:"pending",
    createdAt:new Date()
  });
  return {bookingId:ref.id};
});

export const onBookingCreated=onDocumentCreated("bookings/{bookingId}",async event=>{
  const data=event.data?.data(); if(!data)return;
  console.log("Booking created",event.params.bookingId,data);
});

export const initiateEsewaPayment=onCall(async request=>{
  if(!request.auth) throw new Error("Authentication required.");
  // Production: create the eSewa transaction server-side and return only
  // the public transaction data required by the eSewa flow.
  return {configured:false,message:"Configure eSewa credentials and verification here."};
});

export const verifyEsewaPayment=onCall(async request=>{
  if(!request.auth) throw new Error("Authentication required.");
  // Never trust a client-provided "paid" flag. Verify with eSewa from server.
  return {verified:false,message:"Server-side eSewa verification must be configured."};
});
